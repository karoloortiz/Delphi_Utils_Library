# Delphi_Async_Library

KLib Version = 3.0

A library with some async utilities for your Delphi Apps.

Dependencies:
 - https://github.com/karoloortiz/Delphi_Utils_Library.git
  
Examples:
  - example-1-async: an example of use "asyncifyMethod", "TAsyncMethod" and "TAsyncMethods" ( implementation of promise.all() from JavaScript ) 
  
TODO:
  - implementing promises


If you need support, add a star to the repository and don't hesitate to contact me at zitrokarol@gmail.com
