# Delphi_Utils_Library

KLib Version = 3.0

A library with some useful utilities for your Delphi Apps.

TODO:
  - examples

If you need support, add a star to the repository and don't hesitate to contact me at zitrokarol@gmail.com